/*
 * SSL_Certificate.c

 *
 *  Created on: 2013-5-8
 *      Author: lis
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "SSL_Analyze.h"
#include "ssl.h"
#include "SSL_Message.h"
#include "SSL_Certificate.h"
#include "SSL_Proc.h"


//debug
#define PRINTF_CERTIFICATE	0
#define PRINTF_CLIENT_HELLO	0

const stValueString_t pastSslVersions[] =
{
    { 0xfeff, "DTLS 1.0" },
    { 0x0100, "DTLS 1.0 (OpenSSL pre 0.9.8f)" },
    { 0x0302, "TLS 1.1" },
    { 0x0301, "TLS 1.0" },
    { 0x0300, "SSL 3.0" },
    { 0x0002, "SSL 2.0" },
    { 0x00, NULL }
};

const stValueString_t g_astCertVersions[] =
{
    {   0, "v1" },
    {   1, "v2" },
    {   2, "v3" },
    {   0, NULL },
};

const stSerialString_t g_astAlgrithomTypes[] =
{
    {{0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x02, 0x02}, "md2"},
    {{0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x02, 0x04}, "md4"},
    {{0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x02, 0x05}, "md5"},
    {{0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x01}, "rsaEncryption"},
    {{0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x02}, "md2WithRSAEncryption"},
    {{0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x03}, "md4WithRSAEncryption"},
    {{0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x04}, "md5WithRSAEncryption"},
    {{0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x05}, "shaWithRSAEncryption"},
    {{0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x06}, "rsaOAEPEncryptionSET"},
    {{0}, NULL},
};

const stSerialString_t g_astUserItemId[] =
{
    {{0X55, 0X04, 0X03}, "commonName"},
    {{0X55, 0X04, 0x0a}, "organizationName"},
    {{0X55, 0X04, 0x0b}, "organizationalUnitName"},
    {{0X55, 0X04, 0x07}, "localityName"},
    {{0X55, 0X04, 0x06}, "countryName"},
    {{0}, NULL},
};



UCHAR ssl_AnalyseCertificate(char *pcSslCertificateData, int iDataLen, ssl_stream *a_ssl_stream, struct streaminfo* a_tcp,
		                      unsigned long long region_flag, int thread_seq, void* a_packet)
{
	int iUnAnaCertLen = iDataLen;	
	char *pcCurSslCertificateData = pcSslCertificateData;
	int return_val = 0;
	memset(a_ssl_stream->stSSLCert->SSLAgID,0,sizeof(a_ssl_stream->stSSLCert->SSLAgID));
        memset(a_ssl_stream->stSSLCert->SSLFPAg,0,sizeof(a_ssl_stream->stSSLCert->SSLFPAg));
        memset(a_ssl_stream->stSSLCert->SSLFrom,0,sizeof(a_ssl_stream->stSSLCert->SSLFrom));
        memset(a_ssl_stream->stSSLCert->SSLIssuer,0,sizeof(a_ssl_stream->stSSLCert->SSLIssuer));
        memset(a_ssl_stream->stSSLCert->SSLSerialNum,0,sizeof(a_ssl_stream->stSSLCert->SSLSerialNum));
        memset(a_ssl_stream->stSSLCert->SSLSub,0,sizeof(a_ssl_stream->stSSLCert->SSLSub));
        memset(a_ssl_stream->stSSLCert->SSLSubBak,0,sizeof(a_ssl_stream->stSSLCert->SSLSubBak));
        memset(a_ssl_stream->stSSLCert->SSLTo,0,sizeof(a_ssl_stream->stSSLCert->SSLTo));
        memset(a_ssl_stream->stSSLCert->SSLVersion,0,sizeof(a_ssl_stream->stSSLCert->SSLVersion));
    while (iUnAnaCertLen > 0)
    {
        a_ssl_stream->stSSLCert->certlen = BtoL3BytesNum(pcCurSslCertificateData);        
         if (a_ssl_stream->stSSLCert->certlen + SSL_CERTIFICATE_HDRLEN > iUnAnaCertLen)
        {
        	/**packet trunked is impossible**/
        	break;
        }
        pcCurSslCertificateData += SSL_CERTIFICATE_HDRLEN;
        iUnAnaCertLen -= SSL_CERTIFICATE_HDRLEN;
        return_val = fn_pGetSSLInfo(pcCurSslCertificateData, a_ssl_stream->stSSLCert->certlen, a_ssl_stream, a_tcp, region_flag, thread_seq, a_packet);
        if( SSL_RETURN_NORM != return_val)   	return return_val;

        a_ssl_stream->output_region_mask = SSL_CERTIFICATE_DETAIL_MASK;
        return_val = ssl_doWithCertificateDetail(&a_ssl_stream, a_tcp, region_flag, thread_seq, a_packet);
        if(SSL_RETURN_NORM != return_val && SSL_RETURN_UNNORM != return_val )  	return return_val;

#if PRINTF_CERTIFICATE
		//printf("a_ssl_stream->stSSLRz->SSLIssuer:%s\n",a_ssl_stream->stSSLCert->SSLIssuer);
		//printf("a_ssl_stream->stSSLRz->SSLSub:%s\n",a_ssl_stream->stSSLCert->SSLSub);
		FILE*               pFile                   = NULL;
        time_t          currTime;
        struct tm	    *now;
        char		    strTime[32];
        char		    logTime[32];
        char filename[64] = {0};
        time(&currTime);
        now = localtime(&currTime);
        memset(strTime, 0, sizeof(strTime) );
        memset(logTime, 0, sizeof(logTime) );
        strftime(strTime, sizeof(strTime), "%Y-%m-%d %H:%M:%S", now);
        strftime(logTime, sizeof(logTime), "%Y-%m-%d", now);
        strcpy(filename, "./ssl_log/ssl_cert_log_"); 
        strcat(filename, logTime);
        if(((pFile = fopen(filename, "a+"))!=NULL))
        {             
           fprintf(pFile,"%s=SSLIssuer==%s\n",strTime, a_ssl_stream->stSSLCert->SSLIssuer);
           fprintf(pFile,"%s=SSLSub==%s\n",strTime, a_ssl_stream->stSSLCert->SSLSub);
           fclose(pFile);  
        }   
#endif
        
        memset(a_ssl_stream->stSSLCert->SSLAgID,0,sizeof(a_ssl_stream->stSSLCert->SSLAgID));
        memset(a_ssl_stream->stSSLCert->SSLFPAg,0,sizeof(a_ssl_stream->stSSLCert->SSLFPAg));
        memset(a_ssl_stream->stSSLCert->SSLFrom,0,sizeof(a_ssl_stream->stSSLCert->SSLFrom));
        memset(a_ssl_stream->stSSLCert->SSLIssuer,0,sizeof(a_ssl_stream->stSSLCert->SSLIssuer));
        memset(a_ssl_stream->stSSLCert->SSLSerialNum,0,sizeof(a_ssl_stream->stSSLCert->SSLSerialNum));
        memset(a_ssl_stream->stSSLCert->SSLSub,0,sizeof(a_ssl_stream->stSSLCert->SSLSub));
        memset(a_ssl_stream->stSSLCert->SSLSubBak,0,sizeof(a_ssl_stream->stSSLCert->SSLSubBak));
        memset(a_ssl_stream->stSSLCert->SSLTo,0,sizeof(a_ssl_stream->stSSLCert->SSLTo));
        memset(a_ssl_stream->stSSLCert->SSLVersion,0,sizeof(a_ssl_stream->stSSLCert->SSLVersion));
		a_ssl_stream->stSSLCert->certlen = 0;
        pcCurSslCertificateData += a_ssl_stream->stSSLCert->certlen;
        iUnAnaCertLen -= a_ssl_stream->stSSLCert->certlen;       
    }
	return SSL_RETURN_NORM;
}


char *fn_pcGetElemType(unsigned char *pucId, int iIdLen, stSerialString_t *pastElemTypes)
{
    int iLoop = 0;
    int iInLoop = 0;
    int iAlgIdLen = 0;

    if (NULL == pucId || iIdLen < 0 || NULL == pastElemTypes)
    {
        return NULL;
    }

    for  (iLoop = 0; NULL != pastElemTypes[iLoop].pcString; ++iLoop)
    {
        iAlgIdLen = strlen((const char *)pastElemTypes[iLoop].aucSerial);
		
        if (iAlgIdLen != iIdLen)
        {
            continue;
        }

        for (iInLoop = 0; iInLoop < iAlgIdLen; ++iInLoop)
        {
            if (pucId[iInLoop] != pastElemTypes[iLoop].aucSerial[iInLoop])
            {
                continue;
            }
        }

        if (iInLoop == iAlgIdLen)
        {
            return (char *)(pastElemTypes[iLoop].pcString);
        }
    }

    return NULL;
}

UCHAR  fn_pGetSSLInfo(char *pcCert, int iLen, ssl_stream *a_ssl_stream,  struct streaminfo *a_tcp,
		        unsigned long long region_flag, int thread_seq, void *a_packet)

{
    /**variable define and initialise**/
    int iUnAnalyseLen = iLen;
    char *pcCurData  = pcCert;
    char *pcIdString = NULL;
    char *pcCurExtData = NULL;
    char *pcCurElemData = NULL;
    char *pcCurExtItem = NULL;
    char acBuffer[8192] = {0};	
    int iCurExtItemLen = 0;
    int uiLength  = 0;
    int iCurItemLen = 0;
    int iCurElemLen = 0;	
    int iExtenLen = 0;
    int iByteNum = 0;
    int iShowFlag = 0;
    int iLoop = 0;
    st_cert_t *stSSLCert = a_ssl_stream->stSSLCert;

    /**validaty check**/
    if (NULL == pcCert || iLen <= 0 || NULL == stSSLCert)
    {
        //printf("1\n");
    	return SSL_RETURN_UNNORM;
    }

    /**certificate length**/
    uiLength = fn_iSslDecodeTagLength(pcCurData, iUnAnalyseLen, &iByteNum);
    if (uiLength <= 0)
    {
    	//printf("2\n");
    	return SSL_RETURN_UNNORM;
    }

    pcCurData += (iByteNum + 1);
    iUnAnalyseLen -= (iByteNum + 1);
    if (iUnAnalyseLen <= 0)
    {
    //	printf("3\n");
        return SSL_RETURN_UNNORM;
    }

    /***signed certificate***/
    uiLength = fn_iSslDecodeTagLength(pcCurData, iUnAnalyseLen, &iByteNum);
    if (uiLength <= 0)
    {
    //	printf("4\n");
    	return SSL_RETURN_UNNORM;
    }

    pcCurData = pcCurData + iByteNum + 1;
    iUnAnalyseLen -= (iByteNum + 1);
    if (iUnAnalyseLen <= 0)
    {
    //	printf("5\n");
    	return SSL_RETURN_UNNORM;
    }

    /**version**/
    uiLength = fn_iSslDecodeTagLength(pcCurData, iUnAnalyseLen, &iByteNum);
    if (uiLength <= 0)
    {
    //	printf("6\n");
    	return SSL_RETURN_UNNORM;
    }

    pcCurElemData = pcCurData + iByteNum + 1;
    iCurElemLen = uiLength;
    pcCurData += (iByteNum + 1 + uiLength);
    iUnAnalyseLen -= (iByteNum + 1 + uiLength);
    if (iUnAnalyseLen <= 0)
    {
    //	printf("7\n");
    	return SSL_RETURN_UNNORM;
    }

    /*get the version*/
    uiLength = fn_iSslDecodeTagLength(pcCurElemData, iCurElemLen, &iByteNum);
    if (uiLength <= 0)
    {
    //	printf("8\n");
    	return SSL_RETURN_UNNORM;
    }

    iCurElemLen -= (iByteNum + 1);
    if (0 > iCurElemLen)
    {
    //	printf("9\n");
    	return SSL_RETURN_UNNORM;
    }
    pcCurElemData += (iByteNum + 1);

    if ((unsigned char)pcCurElemData[0] < 3)
    {
		unsigned int i = (unsigned int)pcCurElemData[0];
        memcpy(stSSLCert->SSLVersion, g_astCertVersions[i].pcString, 1 + strlen((const char *)g_astCertVersions[i].pcString));
    }

    /**serial number**/
    uiLength = fn_iSslDecodeTagLength(pcCurData, iUnAnalyseLen, &iByteNum);
    if (uiLength <= 0)
    {
    //	printf("10\n");
    	return SSL_RETURN_UNNORM;
    }
    /*find the serial*/
    iUnAnalyseLen -= (iByteNum + 1 + uiLength);
    if (iUnAnalyseLen <= 0)
    {
    //	printf("11\n");
    	return SSL_RETURN_UNNORM;
    }


    for (iLoop = 0; iLoop < (uiLength>=128/3?(128/3-1):uiLength); ++iLoop)
    {
        fn_vPrintNum(stSSLCert->SSLSerialNum+3*iLoop, (unsigned char)pcCurData[iByteNum + 1+iLoop]);
        stSSLCert->SSLSerialNum[3*(1+iLoop)-1] = ' ';
        stSSLCert->SSLSerialNum[3*(1+iLoop)] = '\0';
    }

    //memcpy(stSSLRz->SSLSerialNum, pcCurData+iByteNum + 1, uiLength>=128?127:uiLength);
    //stSSLRz->SSLSerialNum[uiLength>=128?127:uiLength] = '\0';

    pcCurData += (iByteNum + 1 + uiLength);

    /**signature**/
    uiLength = fn_iSslDecodeTagLength(pcCurData, iUnAnalyseLen, &iByteNum);
    if (uiLength <= 0)
    {
    //	printf("12\n");
    	return SSL_RETURN_UNNORM;
    }

    pcCurElemData = pcCurData + iByteNum + 1;
    iCurElemLen = uiLength;
    pcCurData += (iByteNum + 1 + uiLength);
    iUnAnalyseLen -= (iByteNum + 1 + uiLength);
    if (iUnAnalyseLen <= 0)
    {
    //	printf("13\n");
    	return SSL_RETURN_UNNORM;
    }
    /*get the signature info*/
    uiLength = fn_iSslDecodeTagLength(pcCurElemData, iCurElemLen, &iByteNum);
    if (uiLength <= 0)
    {
    //	printf("14\n");
    	return SSL_RETURN_UNNORM;
    }

    iCurElemLen -= (iByteNum + 1);
    if (0 > iCurElemLen)
    {
    //	printf("15\n");
    	return SSL_RETURN_UNNORM;
    }
    pcCurElemData += (iByteNum + 1);

    pcIdString = fn_pcGetElemType((unsigned char *)pcCurElemData, uiLength, (stSerialString_t*)g_astAlgrithomTypes);
    if (NULL != pcIdString)
    {
        memcpy(stSSLCert->SSLAgID, pcIdString, 1 + strlen((const char *)pcIdString));
    }


    /**issuer**/
    uiLength = fn_iSslDecodeTagLength(pcCurData, iUnAnalyseLen, &iByteNum);
    if (uiLength <= 0)
    {
    //	printf("16\n");
    	return SSL_RETURN_UNNORM;
    }
    iUnAnalyseLen -= (iByteNum + 1 + uiLength);
    if (iUnAnalyseLen <= 0)
    {
    //	printf("17\n");
    	return SSL_RETURN_UNNORM;
    }
    pcCurElemData = pcCurData + iByteNum + 1;
    iCurElemLen = uiLength;
    pcCurData += (iByteNum + 1 + uiLength);


    /*get the issuer info*/
    while (iCurElemLen > 0)
    {
        uiLength = fn_iSslDecodeTagLength(pcCurElemData, iCurElemLen, &iByteNum);
        if (uiLength <= 0)
        {
      //  	printf("18\n");
        	return SSL_RETURN_UNNORM;
        }

        iCurElemLen -= (iByteNum + 1);
        if (0 > iCurElemLen)
        {
        //	printf("19\n");
        	return SSL_RETURN_UNNORM;
        }
        pcCurElemData += (iByteNum + 1);

        uiLength = fn_iSslDecodeTagLength(pcCurElemData, iCurElemLen, &iByteNum);
        if (uiLength <= 0)
        {
        //	printf("20\n");
        	return SSL_RETURN_UNNORM;
        }

        iCurElemLen -= (iByteNum + 1);
        if (0 > iCurElemLen)
        {
        //	printf("21\n");
        	return SSL_RETURN_UNNORM;
        }
        pcCurElemData += (iByteNum + 1);

        /*next level:first elem*/
        uiLength = fn_iSslDecodeTagLength(pcCurElemData, iCurElemLen, &iByteNum);
        if (uiLength <= 0)
        {
        //	printf("22\n");
        	return SSL_RETURN_UNNORM;
        }

        iCurElemLen -= (iByteNum + 1 + uiLength);
        if (0 > iCurElemLen)
        {
        //	printf("23\n");
        	return SSL_RETURN_UNNORM;
        }
        pcCurElemData += (iByteNum + 1);
        if (NULL == fn_pcGetElemType((unsigned char *)pcCurElemData, uiLength, (stSerialString_t*)g_astUserItemId))
        {
            iShowFlag = 0;
        }
        else
        {
            iShowFlag = 1;
        }        
        pcCurElemData += uiLength;
        /*second elem*/
        uiLength = fn_iSslDecodeTagLength(pcCurElemData, iCurElemLen, &iByteNum);
        if (uiLength <= 0)
        {
        //	printf("24\n");
        	return SSL_RETURN_UNNORM;
        }

        iCurElemLen -= (iByteNum + 1);
        if (0 > iCurElemLen)
        {
        //	printf("25\n");
        	return SSL_RETURN_UNNORM;
        }
        pcCurElemData += (iByteNum + 1);

        if (1 == iShowFlag)
        {
			//malformation ssl certificate
			if(uiLength>(int)sizeof(acBuffer))
			{
				return SSL_RETURN_DROPME;
			}
            memcpy(acBuffer, pcCurElemData, uiLength);
            acBuffer[uiLength] = ';';
            acBuffer[uiLength+1] = '\0';
            memcpy(acBuffer+strlen((const char *)acBuffer), stSSLCert->SSLIssuer, 1 + strlen((const char *)stSSLCert->SSLIssuer));
            iCurItemLen = strlen((const char *)acBuffer);
            memcpy(stSSLCert->SSLIssuer, acBuffer, iCurItemLen >= 512 ? 511 : iCurItemLen);
            stSSLCert->SSLIssuer[ iCurItemLen >= 512 ? 511 : iCurItemLen] = '\0';
        }

        iCurElemLen -= uiLength;
        pcCurElemData += uiLength;
    }


    /**validaty**/
    uiLength = fn_iSslDecodeTagLength(pcCurData, iUnAnalyseLen, &iByteNum);
    if (uiLength <= 0)
    {
        return SSL_RETURN_UNNORM;
    }
    pcCurElemData = pcCurData + iByteNum + 1;
    iCurElemLen = uiLength;
    pcCurData += (iByteNum + 1 + uiLength);
    iUnAnalyseLen -= (iByteNum + 1 + uiLength);
    if (iUnAnalyseLen <= 0)
    {
        return SSL_RETURN_UNNORM;
    }
    /*get the validaty info*/
    uiLength = fn_iSslDecodeTagLength(pcCurElemData, iCurElemLen, &iByteNum);
    if (uiLength <= 0)
    {
    //	printf("26\n");
    	return SSL_RETURN_UNNORM;
    }

    iCurElemLen -= (iByteNum + 1);
    if (0 > iCurElemLen)
    {
    //	printf("27\n");
    	return SSL_RETURN_UNNORM;
    }
    pcCurElemData += (iByteNum + 1);

    /*utcTime*/
    if (0x0d == uiLength && 0x5a == pcCurElemData[uiLength-1])
    {
	   unsigned int str_len = 0;
       sprintf(stSSLCert->SSLFrom, "%c%c-%c%c-%c%c %c%c:%c%c:%c%c(UTC)", pcCurElemData[0], pcCurElemData[1], pcCurElemData[2], pcCurElemData[3],
                pcCurElemData[4], pcCurElemData[5], pcCurElemData[6], pcCurElemData[7], pcCurElemData[8], pcCurElemData[9], pcCurElemData[10], pcCurElemData[11]);
	   str_len = MIN(strlen(stSSLCert->SSLFrom), (sizeof(stSSLCert->SSLFrom)-1));
	   stSSLCert->SSLFrom[str_len] = '\0';
	}
    //else if (1)
    else
    {
    /*generalizedTime*/
        memcpy(stSSLCert->SSLFrom, pcCurElemData, uiLength>=80?79:uiLength);
        stSSLCert->SSLFrom[uiLength>=80?79:uiLength] = '\0';
    }

    pcCurElemData += uiLength;

    uiLength = fn_iSslDecodeTagLength(pcCurElemData, iCurElemLen, &iByteNum);
    if (uiLength <= 0)
    {
    //	printf("28\n");
    	return SSL_RETURN_UNNORM;
    }

    iCurElemLen -= (iByteNum + 1 - uiLength);
    if (0 > iCurElemLen)
    {
    //	printf("29\n");
    	return SSL_RETURN_UNNORM;
    }
    pcCurElemData += (iByteNum + 1);

    if (0x0d == uiLength && 0x5a == pcCurElemData[uiLength-1])
    {
		unsigned int str_len = 0;
		sprintf(stSSLCert->SSLTo, "%c%c-%c%c-%c%c %c%c:%c%c:%c%c(UTC)", pcCurElemData[0], pcCurElemData[1], pcCurElemData[2], pcCurElemData[3],
                pcCurElemData[4], pcCurElemData[5], pcCurElemData[6], pcCurElemData[7], pcCurElemData[8], pcCurElemData[9], pcCurElemData[10], pcCurElemData[11]);
		str_len = MIN(strlen(stSSLCert->SSLTo), (sizeof(stSSLCert->SSLTo)-1));
		stSSLCert->SSLTo[str_len] = '\0';
    }
//    else if (1)
		else
    {
    /*generalizedTime*/
        memcpy(stSSLCert->SSLTo, pcCurElemData, uiLength>=80?79:uiLength);
        stSSLCert->SSLTo[uiLength>=80?79:uiLength] = '\0';
    }

    /**subject**/
    uiLength = fn_iSslDecodeTagLength(pcCurData, iUnAnalyseLen, &iByteNum);
    if (uiLength <= 0)
    {
    //	printf("30\n");
    	return SSL_RETURN_UNNORM;
    }
    iUnAnalyseLen -= (iByteNum + 1 + uiLength);
    if (iUnAnalyseLen <= 0)
    {
        return SSL_RETURN_UNNORM;
    }
    //memcpy(stSSLRz->SSLSub, pcCurData+iByteNum + 1, uiLength);

    pcCurElemData = pcCurData + (iByteNum + 1);
    iCurElemLen = uiLength;

    pcCurData += (iByteNum + 1 + uiLength);

  /*get the subject info*/
    while (iCurElemLen > 0)
    {
        uiLength = fn_iSslDecodeTagLength(pcCurElemData, iCurElemLen, &iByteNum);
        if (uiLength <= 0)
        {
      //  	printf("31\n");
        	return SSL_RETURN_UNNORM;
        }

        iCurElemLen -= (iByteNum + 1);
        if (0 > iCurElemLen)
        {
        //	printf("32\n");
        	return SSL_RETURN_UNNORM;
        }
        pcCurElemData += (iByteNum + 1);

        uiLength = fn_iSslDecodeTagLength(pcCurElemData, iCurElemLen, &iByteNum);
        if (uiLength <= 0)
        {
        //	printf("33\n");
        	return SSL_RETURN_UNNORM;
        }

        iCurElemLen -= (iByteNum + 1);
        if (0 > iCurElemLen)
        {
        //	printf("34\n");
        	return SSL_RETURN_UNNORM;
        }
        pcCurElemData += (iByteNum + 1);

        /*next level:first elem*/
        uiLength = fn_iSslDecodeTagLength(pcCurElemData, iCurElemLen, &iByteNum);
        if (uiLength <= 0)
        {
        //	printf("35\n");
        	return SSL_RETURN_UNNORM;
        }

        iCurElemLen -= (iByteNum + 1 + uiLength);
        if (0 > iCurElemLen)
        {
        //	printf("36\n");
        	return SSL_RETURN_UNNORM;
        }
        pcCurElemData += (iByteNum + 1);
        if (NULL == fn_pcGetElemType((unsigned char *)pcCurElemData, uiLength, (stSerialString_t*)g_astUserItemId))
        {
            iShowFlag = 0;
        }
        else
        {
            iShowFlag = 1;
        }

        pcCurElemData += uiLength;
        /*second elem*/
        uiLength = fn_iSslDecodeTagLength(pcCurElemData, iCurElemLen, &iByteNum);
        if (uiLength <= 0)
        {
        //	printf("37\n");
        	return SSL_RETURN_UNNORM;
        }

        iCurElemLen -= (iByteNum + 1);
        if (0 > iCurElemLen)
        {
            return SSL_RETURN_UNNORM;
        }
        pcCurElemData += (iByteNum + 1);

        if (1 == iShowFlag)
        {
        //malformation ssl certificate
			if(uiLength>(int)sizeof(acBuffer))
			{
				return SSL_RETURN_DROPME;
			}
            memcpy(acBuffer, pcCurElemData, uiLength);
            acBuffer[uiLength] = ';';
            acBuffer[uiLength+1] = '\0';
            memcpy(acBuffer+strlen((const char *)acBuffer), stSSLCert->SSLSub, 1 + strlen((const char *)stSSLCert->SSLSub));
            iCurItemLen = strlen((const char *)acBuffer);
            memcpy(stSSLCert->SSLSub, acBuffer, iCurItemLen >= 512 ? 511 : iCurItemLen);
            stSSLCert->SSLSub[iCurItemLen >= 512 ? 511 : iCurItemLen ] = '\0';

        }

        iCurElemLen -= uiLength;
        pcCurElemData += uiLength;
    }

	/*add by 20141120*/
	 /**subject public key info**/
    uiLength = fn_iSslDecodeTagLength(pcCurData, iUnAnalyseLen, &iByteNum);
    if (uiLength <= 0)
    {
		return SSL_RETURN_UNNORM;
    }
    pcCurData += (iByteNum + 1 + uiLength);
    iUnAnalyseLen -= (iByteNum + 1 + uiLength);
    if (iUnAnalyseLen <= 0)
    {
		return SSL_RETURN_UNNORM;
    }

    /**extensions**/
    /*level 1: extention items length*/
    iExtenLen = fn_iSslDecodeTagLength(pcCurData, iUnAnalyseLen, &iByteNum);
    if (iExtenLen <= 0)
    {
		return SSL_RETURN_UNNORM;
    }
    pcCurExtData = pcCurData + iByteNum + 1;
    pcCurData += (iByteNum + 1 + iExtenLen);
    iUnAnalyseLen -= (iByteNum + 1 + iExtenLen);
    if (iUnAnalyseLen < 0)
    {
		return SSL_RETURN_UNNORM;
    }

    /*level 2: extention items*/
    iExtenLen = fn_iSslDecodeTagLength(pcCurExtData, iExtenLen, &iByteNum);
    if (iExtenLen <= 0)
    {
		return SSL_RETURN_UNNORM;
    }
    pcCurExtData += (iByteNum + 1);

    while (iExtenLen > 0)
    {
        /*current item length*/
        iCurExtItemLen = fn_iSslDecodeTagLength(pcCurExtData, iExtenLen, &iByteNum);
        if (iCurExtItemLen <= 0)
        {
        	return SSL_RETURN_UNNORM;
        }

        pcCurExtItem = pcCurExtData + iByteNum + 1;
        pcCurExtData += (iByteNum + 1 + iCurExtItemLen);
        iExtenLen -= (iByteNum + 1 + iCurExtItemLen);
        if (iExtenLen < 0)
        {
        	return SSL_RETURN_UNNORM;
        }

        /*extention item id length*/
        uiLength = fn_iSslDecodeTagLength(pcCurExtItem, iCurExtItemLen, &iByteNum);
        if (uiLength <= 0)
        {
        	return SSL_RETURN_UNNORM;
        }
        pcCurExtItem += (iByteNum + 1);
        iCurExtItemLen -= (iByteNum + 1);

        /*alter subject id*/
        if (3 == uiLength && 0x55 == pcCurExtItem[0] && 0x1d == pcCurExtItem[1] && 0x11 == pcCurExtItem[2])
        {
            /*subject alter name*/
            pcCurExtItem += uiLength;
            iCurExtItemLen -= uiLength;
            uiLength = fn_iSslDecodeTagLength(pcCurExtItem, iCurExtItemLen, &iByteNum);
            if (uiLength <= 0)
            {
				return SSL_RETURN_UNNORM;
            }

            pcCurExtItem += (iByteNum + 1);
            iCurExtItemLen -= (iByteNum + 1 + uiLength);
            if (iCurExtItemLen < 0)
            {
				return SSL_RETURN_UNNORM;
            }


            /*get the last piece*/
            pcCurElemData = pcCurExtItem;
            iCurElemLen = uiLength;

            
            while (iCurElemLen > 0)
            {
                uiLength = fn_iSslDecodeTagLength(pcCurElemData, iCurElemLen, &iByteNum);
                if (uiLength <= 0)
                {
					return SSL_RETURN_UNNORM;
                }

                iCurElemLen -= (iByteNum + 1 + uiLength);
                if (0 > iCurElemLen)
                {
					return SSL_RETURN_UNNORM;
                }
                pcCurElemData += (iByteNum + 1 + uiLength);
            }
            pcCurElemData -= uiLength;
            memcpy(stSSLCert->SSLSubBak, pcCurElemData, uiLength>=512?511:uiLength);
            stSSLCert->SSLSubBak[uiLength>=512?511:uiLength] = '\0';
        }
    }


    /**algorithm identifier**/
    uiLength = fn_iSslDecodeTagLength(pcCurData, iUnAnalyseLen, &iByteNum);
    if (uiLength <= 0)
    {
		return SSL_RETURN_UNNORM;
    }
    pcCurExtData = pcCurData + iByteNum + 1;
    iExtenLen = uiLength;
    pcCurData += (iByteNum + 1 + uiLength);
    iUnAnalyseLen -= (iByteNum + 1 + uiLength);
    if (iUnAnalyseLen <= 0)
    {
		return SSL_RETURN_UNNORM;
    }

    uiLength = fn_iSslDecodeTagLength(pcCurExtData, iExtenLen, &iByteNum);
    if (uiLength <= 0)
    {
		return SSL_RETURN_UNNORM;
    }

    iExtenLen -= (iByteNum + 1);
    if (0 > iExtenLen)
    {
		return SSL_RETURN_UNNORM;
    }
    pcCurExtData += (iByteNum + 1);

    pcIdString = fn_pcGetElemType((unsigned char *)pcCurExtData, uiLength, (stSerialString_t*)g_astAlgrithomTypes);
    if (NULL != pcIdString)
    {
        memcpy(stSSLCert->SSLFPAg, pcIdString, 1 + strlen((const char *)pcIdString));
    }

    pcCurExtData += uiLength;
    /**padding**/
    /**encrypted**/
	
    return SSL_RETURN_NORM;
}
